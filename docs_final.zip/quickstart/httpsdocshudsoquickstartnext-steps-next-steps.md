# (https://docs.hud.so/quickstart#next-steps) Next Steps

**Parent**: [Quickstart - hud SDK](../quickstart.md)

- **[Task Creation Guide](https://docs.hud.so/task-creation)**: Deep dive into building custom evaluation scenarios
- **[Custom Environments](https://docs.hud.so/environment-creation)**: Create Docker-based environments for your applications
- **[Browser Environment](https://docs.hud.so/environments/browser)**: Learn browser-specific features
- **[Examples](https://docs.hud.so/examples)**: Browse runnable notebooks

---

## (https://docs.hud.so/quickstart#custom-installation-%26-setup) Custom Installation & Setup

If you haven’t installed the SDK yet, here’s how:

### (https://docs.hud.so/quickstart#standard-installation) Standard Installation

Install the HUD SDK using pip:

### (https://docs.hud.so/quickstart#requirements) Requirements

- **Python:** 3.10 or higher
- **API Keys:**
  - `HUD_API_KEY` (required for platform features like job/trace uploading, loading remote TaskSets).
  - `OPENAI_API_KEY` (optional, required if using `OperatorAgent` or other OpenAI-based agents).
  - `ANTHROPIC_API_KEY` (optional, required if using `ClaudeAgent` or other Anthropic-based agents).

### (https://docs.hud.so/quickstart#api-key-configuration) API Key Configuration

The SDK automatically loads API keys from environment variables or a `.env` file located in your project’s root directory.

Create a `.env` file in your project root:

Alternatively, export them as environment variables in your shell.

### (https://docs.hud.so/quickstart#development-installation-for-contributors) Development Installation (for Contributors)

If you plan to contribute to the SDK or need an editable install:

With the SDK installed and API keys configured, you’re ready to explore all examples and build your own agent evaluations!

[Tasks](https://docs.hud.so/task-creation)