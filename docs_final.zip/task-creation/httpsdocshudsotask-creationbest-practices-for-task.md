# (https://docs.hud.so/task-creation#best-practices-for-task-design) Best Practices for Task Design

**Parent**: [Tasks - hud SDK](../task-creation.md)

1. **Clear Prompts**: Ensure agent understands the goal and success criteria.
2. **Atomic Tasks**: Break down complex goals into smaller, testable tasks.
3. **Robust Setup**: Create consistent starting states.
4. **Comprehensive Evaluation**: Use multiple evaluation functions to validate success.
5. **Iterate**: Test and refine tasks, especially evaluation logic.

## (https://docs.hud.so/task-creation#advanced-patterns) Advanced Patterns

### (https://docs.hud.so/task-creation#environment-specific-evaluation) Environment-Specific Evaluation

### (https://docs.hud.so/task-creation#dynamic-task-generation) Dynamic Task Generation

## (https://docs.hud.so/task-creation#related-guides) Related Guides

- **[Browser Environment](https://docs.hud.so/environments/browser)**: Detailed guide on using `hud-browser`, including all its setup and evaluation functions.
- **[Environment Creation & Contribution](https://docs.hud.so/environment-creation)**: For tasks requiring specialized Docker-based environments.
- **[Quickstart](https://docs.hud.so/quickstart)**: Introductory examples and common usage patterns.
- **[API Reference](https://docs.hud.so/api-reference)**: Comprehensive details for all SDK modules and classes.

[Quickstart](https://docs.hud.so/quickstart)[Environments](https://docs.hud.so/environment-creation)