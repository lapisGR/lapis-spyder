# 4. Browser Interaction Patterns

**Parent**: [Quickstart - hud SDK](../quickstart.md)

### Live Streaming

Copy

### Browser Use Integration through CDP

Copy

## 5. TaskSet Evaluation

Evaluate your agent on pre-built TaskSets:

Copy

## 6. MCP Telemetry Integration

HUD automatically captures MCP tool calls for debugging:

Copy
**What’s Captured**:

- Tool invocations and responses
- Error states and retries
- Performance data
- Request/response payloads

## 7. Common Task Patterns

### Question Answering

Copy

### Form Interaction

Copy

### Spreadsheet Tasks

Copy

### Response-Only Tasks (No Browser)

Copy

## Next Steps

- **[Task Creation Guide](https://docs.hud.so/task-creation)**: Deep dive into building custom evaluation scenarios
- **[Custom Environments](https://docs.hud.so/environment-creation)**: Create Docker-based environments for your applications
- **[Browser Environment](https://docs.hud.so/environments/browser)**: Learn browser-specific features
- **[Examples](https://docs.hud.so/examples)**: Browse runnable notebooks

---

## Custom Installation & Setup

If you haven’t installed the SDK yet, here’s how:

### Standard Installation

Install the HUD SDK using pip:

Copy

### Requirements

- **Python:** 3.10 or higher
- **API Keys:**
	- `HUD_API_KEY` (required for platform features like job/trace uploading, loading remote TaskSets).
	- `OPENAI_API_KEY` (optional, required if using `OperatorAgent` or other OpenAI-based agents).
	- `ANTHROPIC_API_KEY` (optional, required if using `ClaudeAgent` or other Anthropic-based agents).

### API Key Configuration

The SDK automatically loads API keys from environment variables or a `.env` file located in your project’s root directory.

Create a `.env` file in your project root:

Copy
Alternatively, export them as environment variables in your shell.

### Development Installation (for Contributors)

If you plan to contribute to the SDK or need an editable install:

Copy
With the SDK installed and API keys configured, you’re ready to explore all examples and build your own agent evaluations!

[Tasks](https://docs.hud.so/task-creation)[github](https://github.com/hud-evals/hud-sdk)[website](https://hud.so)[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=docs.hud.so)