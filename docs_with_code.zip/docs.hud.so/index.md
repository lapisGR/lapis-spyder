# docs.hud.so Documentation

- [Quickstart - hud SDK](https://docs.hud.so/)
          - [Getting Started](https://docs.hud.so/#getting-started): - Quickstart - Tasks - Environments - Agents
          - [Examples](https://docs.hud.so/#examples): - Benchmarking agents - Alignment evaluation - Custom OS environment - MCP & multi-tool agents - Website testing
          - [Features](https://docs.hud.so/#features): - Tracing - CLA Action Details - Advanced Environment Control - Uploading TaskSets
          - [Concepts](https://docs.hud.so/#concepts): - Agent - Adapter - Environment - Job - Tasks and TaskSets - Trajectory
          - [Environments](https://docs.hud.so/#environments)
  - [Quickstart](https://docs.hud.so/#quickstart)
    - [1. Installation](https://docs.hud.so/#1-installation)
    - [2. API Key Setup](https://docs.hud.so/#2-api-key-setup)
    - [3. Your First Task](https://docs.hud.so/#3-your-first-task)
      - [Manual Agent Loop](https://docs.hud.so/#manual-agent-loop)
    - [4. Browser Interaction Patterns](https://docs.hud.so/#4-browser-interaction-patterns)
      - [Live Streaming](https://docs.hud.so/#live-streaming)
      - [Browser Use Integration through CDP](https://docs.hud.so/#browser-use-integration-through-cdp)
    - [5. TaskSet Evaluation](https://docs.hud.so/#5-taskset-evaluation)
    - [6. MCP Telemetry Integration](https://docs.hud.so/#6-mcp-telemetry-integration)
    - [7. Common Task Patterns](https://docs.hud.so/#7-common-task-patterns)
      - [Question Answering](https://docs.hud.so/#question-answering)
      - [Form Interaction](https://docs.hud.so/#form-interaction)
      - [Spreadsheet Tasks](https://docs.hud.so/#spreadsheet-tasks)
      - [Response-Only Tasks (No Browser)](https://docs.hud.so/#response-only-tasks-no-browser)
    - [Next Steps](https://docs.hud.so/#next-steps)
    - [Custom Installation & Setup](https://docs.hud.so/#custom-installation-setup)
      - [Standard Installation](https://docs.hud.so/#standard-installation)
      - [Requirements](https://docs.hud.so/#requirements)
      - [API Key Configuration](https://docs.hud.so/#api-key-configuration)
      - [Development Installation (for Contributors)](https://docs.hud.so/#development-installation-for-contributors)

- [Quickstart - hud SDK](https://docs.hud.so/quickstart): This Quickstart guide provides a comprehensive introduction to the HUD SDK, covering essential steps from installation and API key configuration to defining and running your first tasks. It demonstrates various agent interaction patterns, including browser automation and evaluation with TaskSets, and highlights key features like MCP telemetry and common task implementation examples. The guide aims to equip users with the foundational knowledge to start building and evaluating agents using the HUD SDK.
          - [Getting Started](https://docs.hud.so/quickstart#getting-started): - Quickstart - Tasks - Environments - Agents
          - [Examples](https://docs.hud.so/quickstart#examples): - Benchmarking agents - Alignment evaluation - Custom OS environment - MCP & multi-tool agents - Website testing
          - [Features](https://docs.hud.so/quickstart#features): - Tracing - CLA Action Details - Advanced Environment Control - Uploading TaskSets
          - [Concepts](https://docs.hud.so/quickstart#concepts): - Agent - Adapter - Environment - Job - Tasks and TaskSets - Trajectory
          - [Environments](https://docs.hud.so/quickstart#environments)
  - [Quickstart](https://docs.hud.so/quickstart#quickstart)
    - [1. Installation](https://docs.hud.so/quickstart#1-installation)
    - [2. API Key Setup](https://docs.hud.so/quickstart#2-api-key-setup)
    - [3. Your First Task](https://docs.hud.so/quickstart#3-your-first-task)
      - [Manual Agent Loop](https://docs.hud.so/quickstart#manual-agent-loop)
    - [4. Browser Interaction Patterns](https://docs.hud.so/quickstart#4-browser-interaction-patterns)
      - [Live Streaming](https://docs.hud.so/quickstart#live-streaming)
      - [Browser Use Integration through CDP](https://docs.hud.so/quickstart#browser-use-integration-through-cdp)
    - [5. TaskSet Evaluation](https://docs.hud.so/quickstart#5-taskset-evaluation)
    - [6. MCP Telemetry Integration](https://docs.hud.so/quickstart#6-mcp-telemetry-integration)
    - [7. Common Task Patterns](https://docs.hud.so/quickstart#7-common-task-patterns)
      - [Question Answering](https://docs.hud.so/quickstart#question-answering)
      - [Form Interaction](https://docs.hud.so/quickstart#form-interaction)
      - [Spreadsheet Tasks](https://docs.hud.so/quickstart#spreadsheet-tasks)
      - [Response-Only Tasks (No Browser)](https://docs.hud.so/quickstart#response-only-tasks-no-browser)
    - [Next Steps](https://docs.hud.so/quickstart#next-steps)
    - [Custom Installation & Setup](https://docs.hud.so/quickstart#custom-installation-setup)
      - [Standard Installation](https://docs.hud.so/quickstart#standard-installation)
      - [Requirements](https://docs.hud.so/quickstart#requirements)
      - [API Key Configuration](https://docs.hud.so/quickstart#api-key-configuration)
      - [Development Installation (for Contributors)](https://docs.hud.so/quickstart#development-installation-for-contributors)

- [Tasks - hud SDK](https://docs.hud.so/task-creation)
          - [Getting Started](https://docs.hud.so/task-creation#getting-started): - Quickstart - Tasks - Environments - Agents
          - [Examples](https://docs.hud.so/task-creation#examples): - Benchmarking agents - Alignment evaluation - Custom OS environment - MCP & multi-tool agents - Website testing
          - [Features](https://docs.hud.so/task-creation#features): - Tracing - CLA Action Details - Advanced Environment Control - Uploading TaskSets
          - [Concepts](https://docs.hud.so/task-creation#concepts): - Agent - Adapter - Environment - Job - Tasks and TaskSets - Trajectory
          - [Environments](https://docs.hud.so/task-creation#environments)
  - [Tasks](https://docs.hud.so/task-creation#tasks): Design, build, and share evaluation scenarios for browser-based agents
  - [Creating Tasks & TaskSets](https://docs.hud.so/task-creation#creating-tasks-tasksets)
    - [Core Task Workflow](https://docs.hud.so/task-creation#core-task-workflow)
    - [Task Structure](https://docs.hud.so/task-creation#task-structure)
    - [Setup Functions (for `hud-browser`)](https://docs.hud.so/task-creation#setup-functions-for-hud-browser)
    - [Evaluate Functions (Verifying Task Success)](https://docs.hud.so/task-creation#evaluate-functions-verifying-task-success)
    - [TaskSet Creation & Management](https://docs.hud.so/task-creation#taskset-creation-management)
      - [Creating a TaskSet](https://docs.hud.so/task-creation#creating-a-taskset)
      - [Uploading & Publishing TaskSets](https://docs.hud.so/task-creation#uploading-publishing-tasksets)
      - [Publishing and Sharing](https://docs.hud.so/task-creation#publishing-and-sharing)
    - [Pre-built TaskSets](https://docs.hud.so/task-creation#pre-built-tasksets)
    - [MCP Telemetry with Tasks](https://docs.hud.so/task-creation#mcp-telemetry-with-tasks)
    - [Best Practices for Task Design](https://docs.hud.so/task-creation#best-practices-for-task-design)
    - [Advanced Patterns](https://docs.hud.so/task-creation#advanced-patterns)
      - [Environment-Specific Evaluation](https://docs.hud.so/task-creation#environment-specific-evaluation)
      - [Dynamic Task Generation](https://docs.hud.so/task-creation#dynamic-task-generation)
    - [Related Guides](https://docs.hud.so/task-creation#related-guides)

## Metadata

- **Domain**: docs.hud.so
- **Total Pages**: 3
- **AI Processed Pages**: 1/3
- **Website ID**: d41d8f44-4e19-4064-b4b7-218490cbcb77
- **Generated**: 2025-06-09 15:50:31 UTC

## AI Enhancement Available

**2 pages** have not been processed with AI enhancement. AI processing adds:

- Detailed summaries for each page and section
- Semantic categorization and tagging
- Improved content structure and navigation
- Enhanced search and discovery capabilities

To process these pages, use the `/content/{website_id}/process` endpoint with the following page IDs:

```json
{
  "page_ids": [
    "8927beac-2951-45be-bf42-6a51982a7318",  // Quickstart - hud SDK
    "db478ddf-2e99-4248-a4bf-1705938c8f0b"  // Tasks - hud SDK
  ]
}
```