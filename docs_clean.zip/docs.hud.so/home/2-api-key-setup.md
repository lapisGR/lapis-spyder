# 2. API Key Setup

**Parent**: [Quickstart - hud SDK](../home.md)

Set your API keys in a `.env` file (get your HUD API key from [app.hud.so](https://app.hud.so)):

## 3. Your First Task

Each gym (`hud-browser`, `OSWorld-Ubuntu`, custom) has it’s own set of setup and evaluate funcitons, and you can define your own.
See [setup](https://docs.hud.so/environments/browser#setup-functions-initial-state) and [evalutors](https://docs.hud.so/environments/browser#evaluation-functions) for more info on available functions.

### Manual Agent Loop

## 4. Browser Interaction Patterns

### Live Streaming

### Browser Use Integration through CDP

## 5. TaskSet Evaluation

Evaluate your agent on pre-built TaskSets:

## 6. MCP Telemetry Integration

HUD automatically captures MCP tool calls for debugging:

**What’s Captured**:

- Tool invocations and responses
- Error states and retries
- Performance data
- Request/response payloads

## 7. Common Task Patterns

### Question Answering

### Form Interaction

### Spreadsheet Tasks

### Response-Only Tasks (No Browser)

## Next Steps

- **[Task Creation Guide](https://docs.hud.so/task-creation)**: Deep dive into building custom evaluation scenarios
- **[Custom Environments](https://docs.hud.so/environment-creation)**: Create Docker-based environments for your applications
- **[Browser Environment](https://docs.hud.so/environments/browser)**: Learn browser-specific features
- **[Examples](https://docs.hud.so/examples)**: Browse runnable notebooks

---

## Custom Installation & Setup

If you haven’t installed the SDK yet, here’s how:

### Standard Installation

Install the HUD SDK using pip:

### Requirements

- **Python:** 3.10 or higher
- **API Keys:**
	- `HUD_API_KEY` (required for platform features like job/trace uploading, loading remote TaskSets).
	- `OPENAI_API_KEY` (optional, required if using `OperatorAgent` or other OpenAI-based agents).
	- `ANTHROPIC_API_KEY` (optional, required if using `ClaudeAgent` or other Anthropic-based agents).

### API Key Configuration

The SDK automatically loads API keys from environment variables or a `.env` file located in your project’s root directory.

Create a `.env` file in your project root:

Alternatively, export them as environment variables in your shell.

### Development Installation (for Contributors)

If you plan to contribute to the SDK or need an editable install:

With the SDK installed and API keys configured, you’re ready to explore all examples and build your own agent evaluations!

[Tasks](https://docs.hud.so/task-creation)[github](https://github.com/hud-evals/hud-sdk)[website](https://hud.so)[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=docs.hud.so)