# Advanced Patterns

**Parent**: [Tasks - hud SDK](../task-creation.md)

### Environment-Specific Evaluation

### Dynamic Task Generation

## Related Guides

- **[Browser Environment](https://docs.hud.so/environments/browser)**: Detailed guide on using `hud-browser`, including all its setup and evaluation functions.
- **[Environment Creation & Contribution](https://docs.hud.so/environment-creation)**: For tasks requiring specialized Docker-based environments.
- **[Quickstart](https://docs.hud.so/quickstart)**: Introductory examples and common usage patterns.
- **[API Reference](https://docs.hud.so/api-reference)**: Comprehensive details for all SDK modules and classes.
[Quickstart](https://docs.hud.so/quickstart)[Environments](https://docs.hud.so/environment-creation)[github](https://github.com/hud-evals/hud-sdk)[website](https://hud.so)[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=docs.hud.so)