# docs.hud.so Documentation

This documentation was generated from the website docs.hud.so using Lapis Spider.

## Structure

- `index.md` - Main documentation index (llms.txt format)
- Each page from the website has its own markdown file
- Major sections (H2 headers) are extracted into separate files in subdirectories

## Navigation

Start with `index.md` to see the complete documentation structure.

## Metadata

- **Generated**: 2025-06-09 15:45:33 UTC
- **Total Pages**: 3
- **Website ID**: d41d8f44-4e19-4064-b4b7-218490cbcb77
