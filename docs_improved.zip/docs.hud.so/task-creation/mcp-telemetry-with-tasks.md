# MCP Telemetry with Tasks

**Parent**: [Tasks - hud SDK](../task-creation.md)

When using MCP-enabled agents, HUD automatically traces tool calls made during task execution if wrapped in `hud.trace()`:

Copy

## Best Practices for Task Design

1. **Clear Prompts**: Ensure agent understands the goal and success criteria.
2. **Atomic Tasks**: Break down complex goals into smaller, testable tasks.
3. **Robust Setup**: Create consistent starting states.
4. **Comprehensive Evaluation**: Use multiple evaluation functions to validate success.
5. **Iterate**: Test and refine tasks, especially evaluation logic.

## Advanced Patterns

### Environment-Specific Evaluation

Copy

### Dynamic Task Generation

Copy

## Related Guides

- **[Browser Environment](https://docs.hud.so/environments/browser)**: Detailed guide on using `hud-browser`, including all its setup and evaluation functions.
- **[Environment Creation & Contribution](https://docs.hud.so/environment-creation)**: For tasks requiring specialized Docker-based environments.
- **[Quickstart](https://docs.hud.so/quickstart)**: Introductory examples and common usage patterns.
- **[API Reference](https://docs.hud.so/api-reference)**: Comprehensive details for all SDK modules and classes.
[Quickstart](https://docs.hud.so/quickstart)[Environments](https://docs.hud.so/environment-creation)[github](https://github.com/hud-evals/hud-sdk)[website](https://hud.so)[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=docs.hud.so)